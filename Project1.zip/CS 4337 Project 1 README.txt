CS 4337 Project 1 README
Seyed Kian Hakim, Harold Foster.
=========================================================

Foster_Hakim_Project_1.rkt: This is the main Scheme code file for the project. It contains functions to evaluate mathematical expressions, format them, and fetch previous results from memory.

Open a coomand line or terminal. For compiling, nagivate to the directory containing the file Foter_Hakim_Project_1.rkt.
Run the command: racket Foster_Hakim_Project_1.rkt
For running the program, a Racket based application is needed.

